<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Other Page</title>
</head>
<body>
    <h1>Other Page</h1>
    <a href='../index.html#07headerscookiessessions'>Back to the start</a>
    <hr>
    <p>This page is the destination page, resulted from a Redirect (or refresh with redirect)</p>
    
</body>
</html>