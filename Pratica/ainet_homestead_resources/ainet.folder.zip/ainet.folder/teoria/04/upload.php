<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Process form: upload file</title>
</head>
<body>
    <h1>Process form: upload file</h1>
    <a href='../index.html#04forms'>Back to the start</a>
    <hr>
    <h3>$_FILES</h3>
    <?php var_dump($_FILES); ?>
    <h3>$_POST</h3>
    <?php var_dump($_POST); ?>
</body>
</html>
