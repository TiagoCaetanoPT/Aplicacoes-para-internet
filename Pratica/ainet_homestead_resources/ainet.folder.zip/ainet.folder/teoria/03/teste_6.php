<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Exemplo de um bloco de código PHP com o mínimo de conteúdo</title>
</head>
<body>
  <h1>Exemplo de um bloco de código PHP com o mínimo de conteúdo</h1>  
  <h3>USAR ESTA ABORDAGEM</h3>
  <p>Usar esta abordagem, porque o código fonte é mais legibilidade e fácil de manter</p>
  <p>
        <?php
        echo date("d/m/y", time());
        ?>
  </p>
  <hr>
  <a href='../index.html#03php'>Voltar ao ínicio</a>

</body>
</html>

