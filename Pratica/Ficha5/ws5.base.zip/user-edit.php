<?php

require 'vendor/autoload.php';

use \Ainet\Controllers\UserController;

$controller = new UserController();
$controller->edit();
