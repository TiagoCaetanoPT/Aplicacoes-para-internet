<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?= $pagetitle ?></title>
        <link rel="stylesheet" href="css/styles.css">
    </head>
    <body>
        <h1><?= $pagetitle ?></h1>
        <a href='../../index.html#09routing'>Back to the start</a>
        <hr>
        <p>            
