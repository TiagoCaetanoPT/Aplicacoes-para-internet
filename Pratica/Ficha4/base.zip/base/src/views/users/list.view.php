<div><a class="btn btn-primary" href="user-add.php">Add user</a></div>
<?php if (count($users)) {
    ?>
    <table class="table table-striped">
    <thead>
        <tr>
            <th>Email</th>
            <th>Fullname</th>
            <th>Registered At</th>
            <th>Type</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $user) {
        ?>
        <tr>
            <td><!-- fill with user->email --></td>
            <td><!-- fill with user->fullname --></td>
            <td><!-- fill with user->registered_at --></td>
            <td><!-- fill with user->type description --></td>
            <td>
            <!-- fill with edit and delete actions -->
            </td>
        </tr>
    <?php

    } ?>
    </table>
<?php

} else {
    ?>
    <h2>No users found</h2>
<?php

} ?>
