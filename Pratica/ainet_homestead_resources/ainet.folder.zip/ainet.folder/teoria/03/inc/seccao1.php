<?php
    require_once 'funcoes.php';
    //require 'funcoes.php';
    
    echo minusculas("<BR><hR>");
    echo minusculas("SECTION 1");
    echo minusculas("<hR>");
