<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Header: Content Disposition</title>
</head>
<body>
    <h1>Header: Content Disposition</h1>
    <a href='../index.html#07headerscookiessessions'>Back to the start</a>
    <hr>
    <p>Link to the <a href="handle_pdf.php">PDF file</a>(handle_pdf.php)</p>
    <p>Image created by PHP (handle_jpeg.pdf) - try to download it and check the file name:</p>
	<p><img src="handle_jpeg.php" src="logotipo"></p>    
</body>
</html>