<?php $__env->startSection('content'); ?>
<div>
    <a href="<?php echo e(action('UserController@create')); ?>">Add User</a>
</div>
<hr>
<table>
<thead>
    <tr>
        <th>Name</th>
        <th>Age</th>
        <th></th>
        <th></th>
    </tr>
</thead>
<tbody>                
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->name); ?> </td>
        <td><?php echo e($user->age); ?> </td>
        <td><a href="<?php echo e(action('UserController@edit', $user->id)); ?>">Edit</a></td>
        <td>
            <form action="<?php echo e(action('UserController@destroy', $user->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <input type="submit" value="Delete">
            </form>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>