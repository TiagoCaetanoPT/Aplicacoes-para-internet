<?php
    header("Refresh: 3; url=other_page.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Header: Refresh Other</title>
</head>
<body>
    <h1>Header: Refresh Other</h1>
    <a href='../index.html#07headerscookiessessions'>Back to the start</a>
    <hr>
    <p>This page will automatically redirect to another page after 3 seconds</p>
</body>
</html>