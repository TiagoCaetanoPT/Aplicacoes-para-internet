<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?= $pagetitle ?></title>
        <link rel="stylesheet" href="<?= route('/css/styles.css')?>">
    </head>
    <body>
        <h1><?= $pagetitle ?></h1>
        <a href='http://ainet.teoria.test/index.html#10laravel'>Back to the start</a>
        <hr>
        <p>            
