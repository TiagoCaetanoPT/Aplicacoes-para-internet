<?php
echo "<!DOCTYPE html>";
echo "<html>";
echo "    <head>";
echo "        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">";
echo "        <title>Exemplo de um bloco de código PHP com todo o conteúdo</title>";
echo "    </head>";
echo "    <body>";
echo "    <h1>Exemplo de um bloco de código PHP com todo o conteúdo</h1>";
echo "    <h3>EVITAR ESTA ABORDAGEM</h3>";
echo "  <p>";
echo date("d/m/y", time());
echo "  </p>";
echo "    <hr>";
echo "    <a href='../index.html#03php'>Voltar ao ínicio</a>";
echo "  </body>";
echo "</html>";
