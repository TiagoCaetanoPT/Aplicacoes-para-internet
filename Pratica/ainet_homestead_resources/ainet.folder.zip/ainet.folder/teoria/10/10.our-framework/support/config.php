<?php

function config($service)
{
    return [
        'dbname' => 'ainet_teoria',
        'host' => '127.0.0.1',
        'port' => '3306',
        'user' => 'homestead',
        'password' => 'secret',
        'charset' => 'utf8'
    ];
}
