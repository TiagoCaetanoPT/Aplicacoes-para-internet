<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo e($pagetitle); ?></title>
        <link rel="stylesheet" href="/css/styles.css">
    </head>
    <body>
        <h1><?php echo e($pagetitle); ?></h1>
        <a href='http://ainet.teoria.test/index.html#10laravel'>Back to the start</a>
        <hr>
        <p>            
            <?php echo $__env->yieldContent('content'); ?>
        </p>
    </body>
</html>