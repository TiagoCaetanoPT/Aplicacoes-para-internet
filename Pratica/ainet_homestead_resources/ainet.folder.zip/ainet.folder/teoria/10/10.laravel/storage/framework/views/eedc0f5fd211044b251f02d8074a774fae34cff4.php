<?php $__env->startSection('content'); ?>
<div>
    <a href="<?php echo e(action('UserController@index')); ?>">Return to the list of users</a>
</div>
<hr>
<form action="<?php echo e(action('UserController@update', $user->id)); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div>
        <label for="inputName">Name</label>
        <input type="text" name="name" id="inputName" placeholder="Name" value="<?php echo e(old('name', $user->name)); ?>">
        <?php if($errors->has('name')): ?>
            <em><?php echo e($errors->first('name')); ?></em>
        <?php endif; ?>
    </div>
    <div>
        <label for="inputAge">Age</label>
        <input type="text" name="age" id="inputAge" placeholder="Age" value="<?php echo e(old('age', $user->age)); ?>">
        <?php if($errors->has('age')): ?>
            <em><?php echo e($errors->first('age')); ?></em>
        <?php endif; ?>
    </div>
    <div>
        <button type="submit" name="ok">Save</button>
        <button type="submit" name="cancel">Cancel</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('users.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>