<?php 
	phpinfo();