<?php
    header("Location: other_page.php");
    //exit();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Header: Redirect</title>
</head>
<body>
    <h1>Header: Redirect</h1>
    <a href='../index.html#07headerscookiessessions'>Back to the start</a>
    <hr>
    <p>This page will never be shown, because of the redirect header</p>
    
</body>
</html>