<?php

namespace Ainet\Models;

class User
{
    public $user_id;
    public $email;
    public $password;
    public $fullname;
    public $registered_at;
    public $type;

    public function __construct(array $attributes = [])
    {
        foreach ($attributes as $name => $value) {
            $this->$name = $value;
        }
    }

    public function typeToStr()
    {
        switch ($this->type) {
            case 0:
                return 'Administrator';
            case 1:
                return 'Publisher';
            case 2:
                return 'Client';
        }

        return 'Unknown';
    }

    public static function all()
    {
        return [
            1 => new self(['user_id' => 1, 'email' => 'ktorp@gmail.com', 'password' => '$2y$10$6kG8pqEsKIRftGX2tw85C.RREhaEZ4kAGhidTEbRdMCoTvHVFtGZa',
                'fullname' => 'Cassandre Greenholt', 'type' => 0, 'registered_at' => '1982-04-29 03:22:51', ]),
            2 => new self(['user_id' => 2, 'email' => 'skyla75@gmail.com', 'password' => '$2y$10$KIqHi/3y2qSQq1VRNdsLNu1ZRLja1TKlV/q./UbznY4D/AKX3WTYy',
                'fullname' => 'Arianna Ferry', 'type' => 0, 'registered_at' => '1989-06-02 12:45:51', ]),
            3 => new self(['user_id' => 3, 'email' => 'bartoletti.denis@hotmail.com', 'password' => '$2y$10$hfkWu.Q2HrW8VcKhD5fwtebXKFpYrOVrDc0RSDVEG5S113gvzjeOe',
                'fullname' => 'Nayeli Morar', 'type' => 1, 'registered_at' => '2000-05-30 22:55:44', ]),
            4 => new self(['user_id' => 4, 'email' => 'gregg.kautzer@yahoo.com', 'password' => '$2y$10$W7PveeimHmFtRcogRdp75um0OZVB7dr9GLceEg3AsBIOJGn9XGlLK',
                'fullname' => 'Zetta Leannon', 'type' => 0, 'registered_at' => '1971-05-14 01:02:16', ]),
            5 => new self(['user_id' => 5, 'email' => 'hjerde@kuhic.biz', 'password' => '$2y$10$XHR5hTMGB1wzsrwm0CLSBe.I0L0Gj6T0uKgIkuCeGw3t7sXMfHmbK',
                'fullname' => 'Joelle Funk', 'type' => 1, 'registered_at' => '2004-05-10 13:07:37', ]),
            6 => new self(['user_id' => 6, 'email' => 'daphne.schuppe@torphy.com', 'password' => '$2y$10$tNGs0SXPY.Ha0mfCBB9LMu74/WO3abT9mrbctO9Vkohf4.2J6fayq',
                'fullname' => 'Kathleen Gleichner', 'type' => 2, 'registered_at' => '1973-10-11 03:09:03', ]),
            7 => new self(['user_id' => 7, 'email' => 'fjacobi@yahoo.com', 'password' => '$2y$10$nJBnOAo8TIlBvR4VTIuOx.KUBAgt2c1o6EdZQlazIzEV5hKER1Dle',
                'fullname' => 'Otha O\'Connell', 'type' => 0, 'registered_at' => '1999-03-21 17:05:29', ]),
            8 => new self(['user_id' => 8, 'email' => 'evans35@moore.com', 'password' => '$2y$10$o5VtDtxfFC8as/vUprRmQ.SP8nx3kx9AE39Ydv5eo3VgLadG0FXbO',
                'fullname' => 'Callie Romaguera', 'type' => 2, 'registered_at' => '1989-12-29 01:24:29', ]),
            9 => new self(['user_id' => 9, 'email' => 'raquel30@gmail.com', 'password' => '$2y$10$Iw9C04IBuk7NHtzq6YYWj.ltvBfwR6Op0KC0QSoDnVYLo2kg9V9cO',
                'fullname' => 'Cruz Rau', 'type' => 1, 'registered_at' => '2000-11-20 22:49:20', ]),
            10 => new self(['user_id' => 10, 'email' => 'trystan.donnelly@farrell.net', 'password' => '$2y$10$CwVAhpW7VEVWma.64EaT1ON0k/zjdku3FeTYivliRheZ0eI5nlpbe',
                'fullname' => 'Desiree Sipes', 'type' => 0, 'registered_at' => '1987-08-11 23:37:52', ]),
        ];
    }

    public static function find($userId)
    {
        $users = static::all();
        if (array_key_exists($userId, $users)) {
            return $users[$userId];
        }

        return;
    }

    public static function add($user)
    {
        var_dump($user);
        die('INSERT STATEMENT HERE');
    }

    public static function save($user)
    {
        var_dump($user);
        die('UPDATE STATEMENT HERE');
    }

    public static function delete($userId)
    {
        var_dump($userId);
        die('DELETE STATEMENT HERE');
    }
}
