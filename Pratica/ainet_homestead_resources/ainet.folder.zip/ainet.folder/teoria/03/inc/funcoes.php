<?php
function minusculas($str)
{
    return strtolower($str);
}
